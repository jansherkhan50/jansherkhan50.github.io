Jansher Khan Amazon PPC Pro — Free Website

1. Open index.html in a browser to preview.
2. Replace the placeholder email, WhatsApp number and LinkedIn URL.
3. To publish free: create a GitHub account, create a repository named USERNAME.github.io,
   upload index.html, then enable GitHub Pages from the repository Settings > Pages.
4. Your free website address will be https://USERNAME.github.io/

No paid domain or hosting is required.
